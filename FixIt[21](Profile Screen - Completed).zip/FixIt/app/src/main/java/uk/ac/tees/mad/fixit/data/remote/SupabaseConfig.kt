package uk.ac.tees.mad.fixit.data.remote

object SupabaseConfig {
    const val SUPABASE_URL = "https://merqjbjhwrzbtoisnmpa.supabase.co"
    const val SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1lcnFqYmpod3J6YnRvaXNubXBhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQzMTQzMTMsImV4cCI6MjA3OTg5MDMxM30.MQeoyzNjOCZSu6tQ5vtaZ50ekJmcC6MN37Gf2Nx_3bU"
    const val STORAGE_BUCKET = "issue-images"
}
